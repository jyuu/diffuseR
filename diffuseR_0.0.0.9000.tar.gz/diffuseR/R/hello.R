#' adds two numbers together.
#' @param x input any real number 
#' @param y input any real number
#' @export 
hello <- function(x,y){x+y}